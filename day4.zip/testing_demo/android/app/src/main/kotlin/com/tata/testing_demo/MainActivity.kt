package com.tata.testing_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
