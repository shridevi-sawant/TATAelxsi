
import 'package:flutter_test/flutter_test.dart';
import 'package:testing_demo/math_utility.dart';

void main(){

    setUp((){
      // executed before each test
      // setup data for test
    });

    tearDown((){
      // executed after each test
      // cleanup test data
    });


    group("MathUtility", (){
      test("testing add", (){
        add_test();
      });

      test("testing subtract", (){
        subtract_test();
      });
    });


}

void add_test(){
  // with - data
  final mUtility = MathUtility();
  int arg1 = 10;
  int arg2 = 20;

  // perform - action
  final result = mUtility.add(arg1, arg2);

  // verify -
  expect(result, 30);
}

void subtract_test(){
  // with - data
  final mUtility = MathUtility();
  int arg1 = 10;
  int arg2 = 20;

  // perform - action
  final result = mUtility.subtract(arg1, arg2);

  // verify -
  expect(result, allOf(isA<int>(), -10));

}