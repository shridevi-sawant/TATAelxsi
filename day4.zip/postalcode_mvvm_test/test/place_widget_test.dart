
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:postalcode_mvvm/main.dart';
import 'package:http/http.dart' as http;


void main(){
  
  testWidgets("Place Widget testing", (tester) async {



    await tester.pumpWidget(const MyApp()); // render widget

    final titleL = find.text("Search for Places");
    expect(titleL, findsOneWidget);

    final pincodeInput = find.byType(TextField);
    expect(pincodeInput, findsOneWidget);

    final searchButton = find.widgetWithText(FilledButton, "SEARCH");
    expect(searchButton, findsOneWidget);




  });
}