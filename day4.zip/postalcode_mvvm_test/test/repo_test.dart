import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:postalcode_mvvm/model/place_info.dart';
import 'package:postalcode_mvvm/model/repository.dart';
import 'package:http/http.dart' as http;
import 'repo_test.mocks.dart';

@GenerateMocks([http.Client])
void main() {
  getPlacesSuccess_test();
  getPlacessFailure_test();
}

void getPlacesSuccess_test() {
  test("getPlaces with success", () async {
    // with
    final mock_http_client = MockClient();
    const pCode = "560011";

    // stubbing
    when(mock_http_client
            .get(Uri.parse("http://api.geonames.org/postalCodeSearchJSON?"
                "postalcode=$pCode&maxRows=10&username=shree")))
        .thenAnswer((_) async {
      return http.Response('''
            {
                "postalCodes": [
                {
                
                "adminName3": "Bangalore South",
                "adminName2": "Bengaluru",
                "countryCode": "IN",
                "postalCode": "560011",
                "adminName1": "Karnataka",
                "placeName": "Jayangar III Block"
                
                }
                ]
            }
            ''', 200);
    });

    final repo = GeonamesRepo(mock_http_client);

    // perform
    final result = await repo.getPlaces(pCode);
    // verify
    expect(result, allOf(isA<List<PlaceInfo>>(), isNotEmpty));
  });
}

void getPlacessFailure_test() {
  test("getPlaces with status code 500", () async {
    final client = MockClient();

    when(client.get(Uri.parse("http://api.geonames.org/postalCodeSearchJSON?"
            "postalcode=560011&maxRows=10&username=shree")))
        .thenAnswer((_) async {
      return http.Response("", 500);
    });

    final repo = GeonamesRepo(client);
    final result = await repo.getPlaces("560011");

    expect(result, isNull);
  });
}
