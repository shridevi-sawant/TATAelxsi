
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:postalcode_mvvm/main.dart';

void main(){

  testWidgets("Place Widget testing", (tester) async {

    await tester.pumpWidget(const MyApp()); // render widget

    final titleL = find.text("Search for Places");
    expect(titleL, findsOneWidget);

    final pincodeInput = find.byType(TextField);
    expect(pincodeInput, findsOneWidget);

    final searchButton = find.widgetWithText(FilledButton, "SEARCH");
    expect(searchButton, findsOneWidget);

    await tester.enterText(pincodeInput, "560011");

    await tester.tap(searchButton);

    await tester.pump(const Duration(seconds: 4));

    final placeList = find.byType(ListView);

    expect(placeList, findsOneWidget);

  });
}