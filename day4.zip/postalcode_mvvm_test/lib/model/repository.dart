
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:postalcode_mvvm/model/place_info.dart';
import 'package:http/http.dart' as http;

class GeonamesRepo {
  final http.Client client;

  GeonamesRepo(this.client);

  Future<List<PlaceInfo>?> getPlaces(String pincode) async {
    final url = "http://api.geonames.org/postalCodeSearchJSON?"
        "postalcode=$pincode&maxRows=10&username=shree";

    debugPrint("URL: $url");

    try {

      final response = await client.get(Uri.parse(url));

      if (response.statusCode == 200) {
        debugPrint(response.body);
        final respData = jsonDecode(response.body)['postalCodes'] as List;
        List<PlaceInfo> placeList = [];
        for (var i = 0; i < respData.length; i++) {
          final place = PlaceInfo.fromJson(respData[i]);
          placeList.add(place);
        }
        debugPrint("Places count: ${placeList.length}");
        return placeList;
      } else {
        debugPrint("HTTP error: ${response.statusCode}");
        return null;
      }
    }catch (err){
      debugPrint("Exception: $err");
      return null;
    }

  }

}