
import 'package:postalcode_mvvm/model/place_info.dart';
import 'package:postalcode_mvvm/model/repository.dart';
import 'package:http/http.dart' as http;

class PlaceViewModel {

  // viewmodel -> repo
  // hold data required by the view

  List<PlaceInfo> _placeList = [];

  List<PlaceInfo> get placeList => _placeList;

  final GeonamesRepo _repo = GeonamesRepo(http.Client());

  Future<bool> fetchPlaces(String pCode) async{
      _placeList = await _repo.getPlaces(pCode) ?? [];

      return _placeList.isNotEmpty ? true : false;
  }
}