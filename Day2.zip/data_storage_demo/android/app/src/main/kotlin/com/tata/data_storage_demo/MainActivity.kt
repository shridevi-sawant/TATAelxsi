package com.tata.data_storage_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
