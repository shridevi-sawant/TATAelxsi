
/*
db for friends names
 */
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

Future<Database> initDatabase() async{
  
  final dbPath = await getDatabasesPath();
  
  return openDatabase(
      join(dbPath, "friends.db"),
      onCreate: (db, _){
        db.execute("create table friend (id integer primary key, name string)");
      },
      version: 1
      );
  
}


void addFriend(String friendName) async {
  // insert
  final db = await initDatabase();
  
  db.insert("friend", {"id": 1, "name" : friendName });
}

Future<List<Map<String, dynamic>>> getFriends() async{
  // query

  final db = await initDatabase();
  return db.query("friend");

}

