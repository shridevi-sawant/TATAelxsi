
import 'package:shared_preferences/shared_preferences.dart';

Future<bool> saveUsername(String uname) async {
  final pref = await SharedPreferences.getInstance();
  return pref.setString("username", uname);
}

Future<String> getUsername() async {
  final pref = await SharedPreferences.getInstance();
  return pref.getString("username") ?? "";
}