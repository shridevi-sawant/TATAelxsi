
import 'dart:io';

import 'package:path_provider/path_provider.dart';

Future<String> getBlogFile() async {
  final appDir = await getApplicationDocumentsDirectory();
  final file = File("${appDir.path}/blog.txt");
  return file.path;
}

void writeBlogText(String blog) async{
  final filePath = await getBlogFile();
  File(filePath).writeAsString(blog);
}

Future<String> readBlogText() async {
  final filePath = await getBlogFile();
  return await File(filePath).readAsString();
}