import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:postalcode_mvvm/view_model/place_view_model.dart';

import '../model/place_info.dart';

// View -> ViewModel
// View get data from viewmodel

class PlaceWidget extends StatefulWidget {
  const PlaceWidget({super.key});


  @override
  State<PlaceWidget> createState() => _PlaceWidgetState();
}

class _PlaceWidgetState extends State<PlaceWidget> {

  final vModel = PlaceViewModel();
  var isDataFetched = false;


  TextEditingController pincodeController = TextEditingController();


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text('Postal Code Search'),),
      body: SafeArea(
          child: Container(
            //color: Colors.amber,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Search for Places"),
                TextField(
                  controller: pincodeController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: "Pincode",
                      hintText: "6 digit postal code"
                  ),
                ),
                FilledButton(onPressed: (){
                  final pincode = pincodeController.text;
                  vModel.fetchPlaces(pincode).then((isDataPresent){
                      setState(() {
                        isDataFetched = isDataPresent;
                      });
                  });

                },
                    child: Text('SEARCH')
                ),
                isDataFetched ?
                Expanded(
                  child: ListView.builder(
                      itemCount: vModel.placeList.length,
                      itemBuilder: (_, idx){
                        final place = vModel.placeList[idx];
                        return PlaceCard(place: place);
                      }),
                )
                    : Text("No Places found")
              ],
            ),
          )
      ),
    );
  }
}

class PlaceCard extends StatelessWidget {
  final PlaceInfo place;

  const PlaceCard({super.key, required this.place});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      tileColor: Colors.cyan,
      title: Text(place.placeName),
      subtitle: Text("${place.city}, ${place.state}, ${place.country}"),
    );
  }
}
