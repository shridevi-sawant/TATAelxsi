package com.tata.postal_code_search

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
