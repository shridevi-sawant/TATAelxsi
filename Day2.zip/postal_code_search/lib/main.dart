import 'package:flutter/material.dart';
import 'package:postal_code_search/NestedListDemo.dart';
import 'package:postal_code_search/WebUitlity.dart';
import 'package:postal_code_search/place_info.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: PlaceWidget(),
      //Nestedlistdemo()
      //
    );
  }
}

class PlaceWidget extends StatefulWidget {
  const PlaceWidget({super.key});



  @override
  State<PlaceWidget> createState() => _PlaceWidgetState();
}

class _PlaceWidgetState extends State<PlaceWidget> {

  TextEditingController pincodeController = TextEditingController();
  List<PlaceInfo> placeList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Postal Code Search'),),
      body: SafeArea(
          child: Container(
            //color: Colors.amber,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Search for Places"),
                TextField(
                  controller: pincodeController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: "Pincode",
                      hintText: "6 digit postal code"
                  ),
                ),
                FilledButton(onPressed: (){
                  final pincode = pincodeController.text;
                  getPlaces(pincode).then((data) {
                    setState(() {
                      placeList = data ?? [];
                    });

                  });
                },
                    child: Text('SEARCH')
                ),
                placeList.isNotEmpty ?
                      Expanded(
                        child: ListView.builder(
                            itemCount: placeList.length,
                            itemBuilder: (_, idx){
                          final place = placeList[idx];
                          return PlaceCard(place: place);
                        }),
                      )
                    : Text("No Places found")
              ],
            ),
          )
      ),
    );
  }
}

class PlaceCard extends StatelessWidget {
  final PlaceInfo place;
  
  const PlaceCard({super.key, required this.place});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      tileColor: Colors.cyan,
      title: Text(place.placeName),
      subtitle: Text("${place.city}, ${place.state}, ${place.country}"),
    );
  }
}
