
class PlaceInfo {

  final String placeName;
  final String? city;
  final String? state;
  final String country;

  PlaceInfo({required this.placeName,
    required this.city,
    required this.state,
    required this.country});

  factory PlaceInfo.fromJson(Map<String, dynamic> data){

    return PlaceInfo(
      placeName: data['placeName'],
      city: data['adminName2'],
      state: data['adminName1'],
      country: data['countryCode']
    );
  }


}