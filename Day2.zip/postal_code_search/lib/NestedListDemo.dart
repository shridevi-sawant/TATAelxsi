import 'package:flutter/material.dart';

class Nestedlistdemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Multiple Lists with Cards'),
        ),
        body: ListsWithCards(),
      ),
    );
  }
}

class ListsWithCards extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Sample data for three lists
    List<List<String>> listsData = [
      ['Item 1'],
      ['Item A', 'Item B', 'Item C', 'Item D', '1', '2', '3', '4'],
      ['Item X', 'Item Y', 'Item Z'],
      ['Item P', 'Item Q', 'Item R'],
      ['Item M', 'Item N', 'Item O'],
    ];

    return ListView.builder(
      itemCount: listsData.length,
      itemBuilder: (context, index) {
        return CardList(listData: listsData[index]);
      },
    );
  }
}

class CardList extends StatelessWidget {
  final List<String> listData;

  CardList({required this.listData});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.amber,
      margin: const EdgeInsets.all(20.0),
      child: Column(

        children: [

          ListTile(
            title: Text('List ${listData[0]}'),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ConstrainedBox(

              constraints: const BoxConstraints(minHeight: 100, maxHeight: 200),
              child: Container(
                padding: const EdgeInsets.all(10),
                color: Colors.blue,
                child: ListView.builder(

                 shrinkWrap: true,
                 physics: const BouncingScrollPhysics(),
                  itemCount: listData.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(listData[index]),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}