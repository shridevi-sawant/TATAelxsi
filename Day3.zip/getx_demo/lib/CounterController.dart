
import 'package:get/state_manager.dart';

class CounterController extends GetxController {

  var _counter = 0.obs;

  get counter => _counter;

  void increment(){
    _counter++;
  }

}