package com.tata.getx_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
