
import 'package:firebase_auth/firebase_auth.dart';

class AuthService{
  final fbAuth = FirebaseAuth.instance;

  Future<User?> registerUser(String email, String pwd) async{
    final result = await fbAuth.createUserWithEmailAndPassword(email: email,
        password: pwd);
    return result.user;
  }

  Future<User?> loginUser(String email, String pwd) async {
    final result = await fbAuth.signInWithEmailAndPassword(email: email,
        password: pwd);
    return result.user;
  }

  void logout(){
    fbAuth.signOut();
  }

}