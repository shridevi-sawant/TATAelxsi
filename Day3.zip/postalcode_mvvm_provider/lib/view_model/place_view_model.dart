
import 'package:flutter/foundation.dart';
import 'package:postalcode_mvvm/model/place_info.dart';
import 'package:postalcode_mvvm/model/repository.dart';

class PlaceViewModel extends ChangeNotifier {

  // viewmodel -> repo
  // hold data required by the view

  List<PlaceInfo> _placeList = [];

  List<PlaceInfo> get placeList => _placeList;

  bool isDataAvailable = false;

  final GeonamesRepo _repo = GeonamesRepo();

  // Future<bool> fetchPlaces(String pCode) async{
  //     _placeList = await _repo.getPlaces(pCode) ?? [];
  //
  //     return _placeList.isNotEmpty ? true : false;
  // }
  void fetchPlaces(String pCode) async{
    _placeList = await _repo.getPlaces(pCode) ?? [];

    if (_placeList.isNotEmpty){
      isDataAvailable = true;
    }else {
      isDataAvailable = false;
    }
    notifyListeners();
  }
}