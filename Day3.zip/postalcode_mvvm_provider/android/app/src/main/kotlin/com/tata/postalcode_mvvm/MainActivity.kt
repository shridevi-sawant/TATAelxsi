package com.tata.postalcode_mvvm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
